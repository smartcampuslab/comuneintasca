#!/bin/sh
node opencontent.js >opencontent.json
